#!/bin/sh
ZABBIX_DIR="/mtj/server/zabbix"
mkdir -p ${ZABBIX_DIR}
#tar zxvf zabbix.tar.gz -C ${ZABBIX_DIR} 1> /dev/null
cp -raf zabbix/* ${ZABBIX_DIR}/
cp -f zabbix_agentd /etc/init.d/;
chmod  +x /etc/init.d/zabbix_agentd 
useradd zabbix -s /sbin/nologin
chown -R zabbix.0 ${ZABBIX_DIR}
sed -i "s/^Hostname=.*$/Hostname=$(hostname)/g" ${ZABBIX_DIR}/etc/zabbix_agentd.conf
if [ `grep zabbix /etc/sudoers|grep -c /mtj/server` -ge 1 ];then
        sed -i '/zabbix/d' /etc/sudoers
fi

cat >>/etc/sudoers <<EOF
zabbix ALL=(root) NOPASSWD:/bin/netstat
zabbix ALL=(root) NOPASSWD:/mtj/server/zabbix/bin/swy_server_discovery.sh
zabbix ALL=(root) NOPASSWD:/mtj/server/zabbix/bin/java_discovery.sh
zabbix ALL=(root) NOPASSWD:/mtj/server/zabbix/bin/tcp_conn_status.sh
zabbix ALL=(root) NOPASSWD:/mtj/server/zabbix/bin/discover_tcp_port_count.sh
zabbix ALL=(root) NOPASSWD:/mtj/server/zabbix/bin/chk_mysql.sh
zabbix ALL=(root) NOPASSWD:/mtj/server/zabbix/bin/chk_redis.sh
zabbix ALL=(root) NOPASSWD:/mtj/server/zabbix/bin/lld-disks.py
EOF

/etc/init.d/zabbix_agentd restart &> /dev/null
#chkconfig --add  zabbix_agentd 
#chkconfig   zabbix_agentd  on
#chkconfig --list |grep zabbix
if [ `grep -c zabbix_agentd /etc/rc.local` -eq 0 ];then
	echo "/etc/init.d/zabbix_agentd start" >> /etc/rc.local
fi
hostname
